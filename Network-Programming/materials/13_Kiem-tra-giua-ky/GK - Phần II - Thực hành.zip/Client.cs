//------------------------------------------------------------------------
// LUU Y: MOI SINH VIEN SE DUOC GIAO DE KHAC NHAU THEO THONG TIN TREN LOP
//
using System.Net.Sockets;
using System.Net;
using System.Text;

int ServerPort = 9999;
Server server = new Server(ServerPort);
server.Start();
//------------------------------------------------------------------------
//A. Dien MSSV cua ban o chuoi ben duoi
string MSSV = "000000002";
//------------------------------------------------------------------------
//B. Lay thong tin cua server tu giang vien
// (cho tren lop)
//-----------------------------------------------------------------------
//C. Hoan thien doan chuong trinh sau de nhan de bai tu server
//-------------------------------------
//C1. Tao socket TCP phia Client, ket noi den mot sever co IP theo thong tin GV cung cap
Socket sckClient = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
//sckClient.Connect(...);
//C2. Nhan loi chao tu server dang chuoi 
byte[] buffer = new byte[1024];
int n = sckClient.Receive(buffer);
string s = Encoding.ASCII.GetString(buffer, 0, n);
System.Console.WriteLine(s);
//C3. Gui chu so cuoi cua MSSV
sckClient.Send(Encoding.ASCII.GetBytes(MSSV[MSSV.Length-1].ToString()));
//C4. Nhan de bai dang chuoi
n = sckClient.Receive(buffer);
//C5. Hien thi de bai
System.Console.WriteLine(Encoding.ASCII.GetString(buffer, 0, n));
//---------------------------------------------------------------------------
//D. Lam theo yeu cau de bai
//---------------------------------------------------------------------------
