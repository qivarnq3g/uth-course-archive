# Đề cương thuyết trình Đề tài 10 (7 mục bắt buộc)

## 1. Cơ sở lý thuyết
- Phát biểu bài toán đường đi ngắn nhất trên đồ thị có trọng số dương.
- Tư tưởng tham lam của Dijkstra: mỗi bước chọn đỉnh có khoảng cách tạm thời nhỏ nhất.
- Điều kiện áp dụng: trọng số không âm.
- Độ phức tạp lý thuyết theo cấu trúc dữ liệu:
  - Adjacency list + min-heap: O((V + E) log V).
  - Adjacency matrix + linear scan: O(V^2).

## 2. Phân tích bài toán
- Mô hình hệ thống giao hàng:
  - Đỉnh: kho bãi/điểm giao.
  - Cạnh: tuyến đường kết nối.
  - Trọng số: chi phí, thời gian, hoặc quãng đường.
- Input:
  - Tập đỉnh, tập cạnh, trọng số dương, source, target.
- Output:
  - Đường đi ngắn nhất, tổng chi phí, trạng thái có/không có đường đi.
- Ràng buộc và giả định:
  - Không có trọng số âm.
  - Dữ liệu hợp lệ theo chỉ số đỉnh.

## 3. Thiết kế thuật toán
- Cấu trúc dữ liệu sử dụng:
  - Graph adjacency list.
  - MatrixGraph adjacency matrix.
  - Distances, Parents, visited.
- Luồng xử lý:
  - Chạy Dijkstra theo list+heap.
  - Chạy Dijkstra theo matrix+scan.
  - Cross-check kết quả khoảng cách để xác minh tính đúng.
- Truy vết đường đi ngắn nhất bằng mảng predecessor (Parents).
- Trình bày giả mã (pseudo-code) cho 2 biến thể.

## 4. Cài đặt chương trình
- Công nghệ: C++20/23, WinUI 3 (C++/WinRT), Desktop unpackaged.
- Tách lớp theo trách nhiệm:
  - Graph.*: mô hình đồ thị adjacency list và validation.
  - MatrixGraph.*: chuyển đổi và truy cập trọng số theo matrix.
  - DijkstraSolver.*: 2 biến thể Dijkstra + benchmark + cross-check.
  - MainWindow.xaml/.cpp: giao diện, render graph, highlight animation, hiển thị benchmark.
- Demo thao tác:
  - Chọn testcase, nhập source/target, số lần benchmark, chạy và đọc kết quả.

## 5. Thử nghiệm và đánh giá
- Bộ test bắt buộc:
  - TC1: reachable.
  - TC2: multi-path.
  - TC3: unreachable.
  - TC4: source = target.
  - TC5: large graph (50 nodes).
- Bảng kết quả expected/actual cho từng testcase.
- Bảng benchmark best/avg/worst cho cả 2 biến thể.
- Nhận xét xu hướng:
  - Đồ thị thưa: list+heap thường nhanh hơn.
  - Đồ thị đặc: matrix+scan có thể cạnh tranh hơn.
- Đối chiếu thực nghiệm với Big-O trong tài liệu phân tích.

## 6. Kết luận và hướng phát triển
- Kết quả đạt được:
  - Giải đúng bài toán đường đi ngắn nhất.
  - Có so sánh đa chiều theo cấu trúc dữ liệu.
- Hạn chế hiện tại:
  - Chưa mô hình hóa traffic real-time và ràng buộc time windows.
- Hướng mở rộng:
  - Nhập dữ liệu JSON từ file.
  - So sánh thêm Bellman-Ford, A*.
  - Mô phỏng logistics sát thực tế hơn.

## 7. Đánh giá thành viên
- Họ tên + MSSV từng thành viên.
- Vai trò chính (thuật toán, UI, benchmark, tài liệu, thuyết trình).
- Tỷ lệ đóng góp có minh chứng (commit, tài liệu, slide).

## Appendix (khuyến nghị để tăng điểm)
- Ảnh chụp UI trước/sau khi highlight path.
- Biểu đồ cột benchmark cho TC1..TC5 (2 biến thể).
- Video demo dự phòng 2-3 phút.
- Slide backup cho phần hỏi đáp:
  - Vì sao Dijkstra không dùng cho trọng số âm?
  - Khi nào nên chọn list+heap, khi nào nên chọn matrix+scan?
