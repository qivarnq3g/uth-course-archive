# Dijkstra Complexity and Benchmark Notes

## 1. Implemented Variants in This Project
- Variant A: adjacency list + min-heap (`std::priority_queue`) in [DijkstraSolver.cpp](DijkstraSolver.cpp).
- Variant B: adjacency matrix + linear scan in [DijkstraSolver.cpp](DijkstraSolver.cpp), with matrix representation in [MatrixGraph.h](MatrixGraph.h) and [MatrixGraph.cpp](MatrixGraph.cpp).
- Both variants are executed for the same input and cross-checked for distance consistency.

## 2. Problem Constraints
- Let $V$ be number of vertices and $E$ number of edges.
- All edge weights are strictly positive (validated in [Graph.cpp](Graph.cpp)).
- Goal: shortest path from one source to one target.

## 3. Theoretical Complexity by Graph Structure

| Variant | Data structure | Time (single run) | Space (excluding UI) | Best use case |
|---|---|---|---|---|
| A | Adjacency list + heap | $O((V + E) \log V)$ | $O(V + E)$ | Sparse graphs ($E$ close to $V$) |
| B | Adjacency matrix + linear scan | $O(V^2)$ | $O(V^2)$ | Dense graphs or very small $V$ |

Interpretation:
- If graph is sparse, Variant A is usually faster and uses less memory.
- If graph is dense ($E \approx V^2$), the time gap narrows and Variant B can be competitive for moderate sizes.

## 4. Best / Average / Worst Perspective
- Best case in this project: source equals target, immediate return ($O(1)$ fast path).
- Average case: depends on graph density and edge distribution.
- Worst case:
  - Variant A: $O((V + E) \log V)$.
  - Variant B: $O(V^2)$.

## 5. Benchmark Method Implemented
- Runtime measured with `std::chrono::high_resolution_clock`.
- Both variants run `K` times (`K` from UI, default 30).
- Metrics displayed in UI status:
  - Best (min), average (mean), worst (max) in microseconds.
- Cross-check status shown as `PASS` if both variants return same reachability and shortest distance.

Benchmark complexity over `K` runs:
- Variant A: $O(K * (V + E) \log V)$.
- Variant B: $O(K * V^2)$.

## 6. Objective Evaluation Checklist
To claim full requirement coverage in presentation/report:
1. Run TC1..TC5 with fixed `K` (for example 30).
2. Record both variants' best/avg/worst from UI output.
3. Add a table for sparse-like vs dense-like datasets.
4. Explain observed trend against the table in Section 3.
5. Include cross-check result to validate correctness consistency.

## 7. Conclusion
This project now satisfies the "evaluate complexity by graph structure" requirement at implementation level by:
- providing two Dijkstra variants tied to two graph structures,
- exposing side-by-side benchmark metrics,
- and validating result consistency between variants.
