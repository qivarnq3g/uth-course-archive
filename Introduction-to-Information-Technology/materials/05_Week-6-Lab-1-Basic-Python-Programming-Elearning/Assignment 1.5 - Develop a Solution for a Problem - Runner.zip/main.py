#If I leave my house at 06:MM:00 AM and run 1 mile at an easy pace (00:08:15 per mile), 
# then 3 miles at tempo (00:07:12 per mile) and 1 mile at easy pace again, 
# what time do I get home for breakfast? 
# Write a program to solve this problem where the minute (MM) is input by the user.

MM = int(input ("Enter the minute: "))

hours = 0
minutes = 0
seconds = 0
# Print the result
print(f"I get home for breakfast at {hours:02d}:{minutes:02d}:{seconds:02d}.")
