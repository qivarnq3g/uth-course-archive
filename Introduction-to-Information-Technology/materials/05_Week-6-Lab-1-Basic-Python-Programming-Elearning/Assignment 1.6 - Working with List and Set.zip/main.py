# Write a program that:
# - Enters two lists of words separated by spaces
# - Prints out the number of distinct words that appear in both lists as well as 
#  the number of distinct words that appear in only one of the lists.
list1 = input("Enter the first list of words separated by spaces: ").split()
list2 = input("Enter the second list of words separated by spaces: ").split()

print("Number of distinct words that appear in both lists:", 9999)
print("Number of distinct words that appear in only one of the lists:", 9999)