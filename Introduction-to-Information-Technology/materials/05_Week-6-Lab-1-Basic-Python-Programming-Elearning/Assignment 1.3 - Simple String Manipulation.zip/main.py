#Enter a number and generate the exact n-character strings below:
# s1 = a string containing only the character '+'
# s2 = a string containing the pattern '+-'
# s3 = a string containing the pattern '+--'
# print the len of the strings at the end of each line
# Hint: use the * operator to concatenate strings, e.g. s1 = '+' * 3 # -->s1 = '+++'
n=int(input("Enter a number: "))
s1= "+"
s2="+-"
s3 = "+--"
print(s1, len(s1))
print(s2, len(s2))
print(s3, len(s3))