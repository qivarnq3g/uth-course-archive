import math

# Get the radius from the user
radius = float(input("Enter the radius of the circle: "))

# Calculate the area


# Round the area to 2 decimal places
rounded_area = round(area, 2)

# Print the result
print("The area of the circle is:", rounded_area)