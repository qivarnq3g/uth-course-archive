# Suppose the cover price of a book is $24.95, but bookstores get a 40% discount. 
# Shipping costs $3 for the first copy and 75 cents for each additional copy. 
# Write a program to input a number of copies and find the total wholesale cost, round the result to two decimal places.

total_copies = int(input("Enter the number of copies: "))
# Calculate the total wholesale cost

total_wholesale_cost = 0
# Print the result
print("The total wholesale cost is: $", round(total_wholesale_cost,2))
