# Enter any number, check if it is even or odd
# Print the result in the format: "2 is even" or "3 is odd"
# Hint: Use the modulus operator % to check if a number is even or odd
num = int(input("Enter a number: "))
if True:
   print("number is Even")
else:
   print("number is Odd")