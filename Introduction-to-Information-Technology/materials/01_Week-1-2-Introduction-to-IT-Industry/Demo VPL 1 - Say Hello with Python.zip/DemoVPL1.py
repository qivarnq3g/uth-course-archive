# Enter the name of the user, 
# and print a greeting message in the form of "hello, <name>!" in one line

name = input("What's your name? ")
name = name.strip()
print(name)