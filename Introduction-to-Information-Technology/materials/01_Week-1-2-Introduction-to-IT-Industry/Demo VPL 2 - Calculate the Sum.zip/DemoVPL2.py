#Complete the code below to calculate the sum of x and y
#and print the result in the format: "The sum of x and y is z"
x = int(input("What's x? "))
y = int(input("What's y? "))

z = 0

print(z)
