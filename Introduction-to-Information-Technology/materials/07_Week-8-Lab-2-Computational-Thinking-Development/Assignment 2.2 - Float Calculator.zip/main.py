#Write a program that asks the user to enter two float numbers and display output in following format:
#Sample Input and Output:
#Enter the first number: 5
#Enter the second number: 6
#a       b       a+b     a-b     a*b     a/b     sqrt(a)
#5.0     6.0     11.00  -1.00    30.00   0.83    2.236
#Hint: Use \t to align the columns; 
#      Round the numbers to 1 decimal place, the operators +,-,*,/ to 2 decimal places and the sqrt to 3 decimal places.
