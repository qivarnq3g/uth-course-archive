#Write a program to display the current date and time in the following format:
#Current date and time is: Tuesday, 23/10/2024, 10:30
#Hint: Use the datetime module to get the current date and time.