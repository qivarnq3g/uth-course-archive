# Write a program to calculate BMI, where  the user enters the weight in kilograms and height in centimeters.
# The program should print the BMI rounded to 2 decimal places and
#  a message about the user's weight status.
# The weight status is determined by the following table:
#   BMI < 18.5: Underweight
#   18.5 <= BMI < 25: Normal
#   25 <= BMI < 30: Overweight
#   BMI >= 30: Obese
# The BMI is calculated as weight (kg) / (height (m))^2

BMI = 0
# Print the BMI and the weight status
print("Your BMI is:", round(BMI,2))
if BMI < 18.5:
    print("You are .")
elif BMI< 25:
    print("You are .")
elif BMI < 30:
    print("You are .")
else:
    print("You are .")