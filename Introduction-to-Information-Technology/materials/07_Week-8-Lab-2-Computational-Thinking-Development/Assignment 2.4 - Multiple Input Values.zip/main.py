#Write a Python program which accepts a list of comma-separated integer numbers from user and display length, sum of items in list.
#Sample Input: 1,2,3,4,5,6,7,8,9,10
#Sample Output: Length: 10, Sum: 55
#Hint: Use the split() method to split the string into a list of strings.

list = input("Enter a list of comma-separated integer numbers: ")


print("Length:", 0)
print("Sum:", 0)
