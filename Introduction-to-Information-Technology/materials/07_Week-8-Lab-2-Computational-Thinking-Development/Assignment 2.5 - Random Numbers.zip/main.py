#Write a program that reads an integer n (1 ≤ n ≤ 10) from the user and prints out 10 random numbers contain exactly n digits.
#Sample Input: 3
#Sample Output: 935
#Hint: Use the random module to generate a random number.
import random
n = int(input("Enter a number between 1 and 10: "))


