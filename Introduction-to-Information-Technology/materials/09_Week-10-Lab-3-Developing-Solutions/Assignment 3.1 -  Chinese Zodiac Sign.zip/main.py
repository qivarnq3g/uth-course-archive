#Write a program that reads a year from the user and displays the Chinese zodiac for that year.
#Sample Input: 2024
#Sample Output: Dragon
#Hint: The Chinese zodiac sign is based on a 12-year cycle, 
# with each year represented by one of 12 animals: Rat, Ox, Tiger, Rabbit, Dragon, Snake, Horse, Goat, Monkey, Rooster, Dog, and Pig.

year = int(input("Enter a year: "))

print("The Chinese zodiac sign is Rat!")