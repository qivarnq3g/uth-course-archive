""" 
Write a function to draw a rectangle.
The function should have two parameters:
- width: the width of the rectangle
- height: the height of the rectangle
The function should draw a rectangle with the given width and height.
Write a program that reads the width and height of a rectangle at the same time, 
separated by comma, and prints the rectangle. 
"""


def drawRectangle(width, height):
    print("")


width, height = eval(input("Enter the width and height of the rectangle, separated by comma: "))
drawRectangle(width, height)