#Write your code here
def isValid(a,b,c):
    return False
    
    
def area(a,b,c):
    return 0
    

a, b, c = eval(input("Enter the three sides of the triangle, separated by comma: "))
if(isValid(a,b,c)):
    print("Area of the triangle is: ",round(area(a,b,c),1))
else:
    print("Invalid")
