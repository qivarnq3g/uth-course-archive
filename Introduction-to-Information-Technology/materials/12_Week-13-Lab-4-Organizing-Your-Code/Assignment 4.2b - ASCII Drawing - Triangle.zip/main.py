""" 
Write a program to draw a triangle.
The function should have one parameter: the height of the triangle
The function should draw a triangle with the given height. 
For example, if the height is 3, the triangle should be:
  *
 ***
*****
Note that if the height of the triangle is float, round it to the nearest integer.
If the height is not number, print "Invalid".
Write a program that reads the height of a triangle and prints the triangle. 
"""

def drawTriangle(height):
    #Your code here


height = eval(input("Enter the height of the triangle: "))
drawTriangle(height)
