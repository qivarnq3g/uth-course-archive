drop table if exists StudentGrade;
drop table if exists Student;
drop table if exists Class;
drop table if exists Subject;   


create table Subject 
( 
	SubjectID char(3) primary key, 
    SubjectName varchar(30), 
    Unit int
);

insert into Subject
values
	('S01', 'Database System', 8),
    ('S02', 'Database Design', 6),
    ('S03', 'Computer Vision', 4),
    ('S04', 'System Analysis and Design', 3),
    ('S05', 'Artificial Intelligence', 5);
    
create table Class
(
	ClassID char(3) primary key,
    ClassName varchar(30),
    ClassYear varchar(30)
);
insert into Class
values ('C01', 'Information Technology', '2024-2028'),
		('C02', 'Computer Science', '2024-2028'),
        ('C03', 'Artificial Intellegent', '2024-2028');
create table Student
(
	StudentID char(3) primary key,
    StudentName varchar(30),
    StudentAddress varchar(30),
    ClassID char(3)
);
insert into Student
values
	('T01', 'Nguyen Van A', 'Quan 01', 'C01'),
    ('T02', 'Nguyen Van B', 'Quan 02', 'C01'),
    ('T03', 'Nguyen Van A', 'Quan 03', 'C01'),
    ('T04', 'Nguyen Van B', 'Quan 04', 'C02'),
    ('T05', 'Nguyen Van B', 'Quan 05', 'C02'),
    ('T06', 'Nguyen Van C', 'Quan 01', 'C02'),
    ('T07', 'Nguyen Van D', 'Quan 02', 'C03'),
    ('T08', 'Nguyen Van D', 'Quan 03', 'C03'),
    ('T09', 'Nguyen Van E', 'Quan 04', 'C03'),
    ('T10', 'Nguyen Van H', 'Quan 05', 'C03');
 
create table StudentGrade 
( 
	StudentID char(3), 
    SubjectID char(3), 
    Grade float,
    primary key(StudentID,SubjectID)
);
insert into StudentGrade
values
	('T01','S01', 4),
    ('T01','S03', 4),
    ('T02','S01', 2),
    ('T03','S01', 9),
    ('T03','S03', 2),
    ('T03','S05', 9),
    ('T04','S01', 7),
    ('T05','S01', 7),
    ('T05','S04', 7),
    ('T06','S01', 10),
    ('T06','S02', 5),
    ('T06','S03', 8),
    ('T06','S04', 9),
    ('T06','S05', 10),
    ('T07','S01', 9),
    ('T07','S02', 5),
    ('T07','S03', 4),
    ('T07','S04', 9),
    ('T07','S05', 8),
    ('T08','S01', 5),
    ('T08','S02', 6),
    ('T08','S03', 7),
    ('T08','S04', 9),
    ('T08','S05', 8);

-- Sinh viên làm sau các câu hỏi sau đây:

-- Câu 1: Cho biết các sinh viên (*) của lớp 'C01':


-- Câu 2: Cho biết các môn học (*) có số tín chỉ từ 4 đến 7:



-- Câu 3: Cho biết các sinh viên (mã số và tên) thi môn 'S01' đạt loại giỏi (điểm >=8):


-- Câu 4: Các môn học (mã số, tên và số tín chỉ) mà sinh viên mã số 'T03' thi đạt (điểm >=5)

