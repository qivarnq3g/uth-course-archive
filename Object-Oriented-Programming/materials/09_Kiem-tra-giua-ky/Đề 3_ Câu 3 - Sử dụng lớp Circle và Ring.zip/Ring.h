#pragma once
#include "Circle.h"
class Ring : public Circle
{
//....
};

