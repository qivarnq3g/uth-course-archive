#pragma once
#include <iostream>
#include <math.h>
using namespace std;
class Circle
{
    //...
};
