#pragma once
class Fraction
{

};