#pragma once
class Point
{
    
};